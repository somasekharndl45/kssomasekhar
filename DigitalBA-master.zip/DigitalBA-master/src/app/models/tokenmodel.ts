export interface TokenModel {
    token: string;
    role : string;
}