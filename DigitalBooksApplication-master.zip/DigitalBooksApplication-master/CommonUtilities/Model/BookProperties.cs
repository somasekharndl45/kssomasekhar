﻿namespace CommonUtilities.Model

{
    public class BookProperties
    {
        public string? Category { get; set; }
        public string? Author { get; set; }
        public decimal? Price { get; set; }
    }
}
