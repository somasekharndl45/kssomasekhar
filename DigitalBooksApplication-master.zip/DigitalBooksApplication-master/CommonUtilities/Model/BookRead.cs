﻿namespace CommonUtilities.Model
{
    public class BookRead
    {
        public string? BookName { get; set; } 
        public string? EmailId { get; set; }
    }
}
