﻿namespace CommonUtilities.Model
{
    public class BuyerDetails
    {
        public string? BuyerName { get; set; }
        public string? EmailId { get; set; }
        public string? BookName { get; set; }
    }
}
